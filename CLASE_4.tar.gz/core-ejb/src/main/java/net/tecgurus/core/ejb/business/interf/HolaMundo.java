package net.tecgurus.core.ejb.business.interf;

import javax.ejb.Local;

@Local
public interface HolaMundo {

	String saluda();

}
